// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.


import { Keccak, shake256 } from '@noble/hashes/sha3';
import {PointG1, PointG2} from './math';
import { HashXOF } from '@noble/hashes/utils';
import { BLS12_381_SHA256_Ciphersuite, Ciphersuite } from './ciphersuite';
import { concatBytes, i2osp } from './utils';

export type SerializeInput = PointG1 | PointG2 | string | number | bigint | Uint8Array;

export function SerializeInputToBytes(data: SerializeInput, cs: Ciphersuite = BLS12_381_SHA256_Ciphersuite): Uint8Array {

  if (typeof data === 'string') {
    return Buffer.from(data, 'utf-8');
  } else if (data instanceof PointG1) {
    return cs.point_to_octets_g1(data);
  } else if (data instanceof PointG2) {
    return cs.point_to_octets_g2(data);
  } else if (typeof data === 'bigint') { // TODO: should I only use Fr?
    return i2osp(data, cs.octet_scalar_length);
  } else if (typeof data === 'number') {
    return i2osp(data, 8);
  } else if (data instanceof Uint8Array) {
    return concatBytes(i2osp(data.length, 8), data);
  } else {
    return cs.point_to_octets_g2(data); // TODO: FIXME!!! why are PK: PointG2 passed as Point?
    throw "invalid serialize type";
  }
}

export class Hash {
  hash = shake256.create({ dkLen: 64 }) as HashXOF<Keccak>;
  constructor() {
  }

  update(data: SerializeInput): void {
    const bytes = SerializeInputToBytes(data);
    const length = bytes.length;
    this.hash.update(i2osp(length, 4));
    this.hash.update(bytes);
  }

  digest(): Uint8Array {
    return this.hash.digest();
  }
}

export class XOF extends Hash {
  constructor() {
    super();
  }

  read(i: number) {
    return this.hash.xof(i);
  }
}
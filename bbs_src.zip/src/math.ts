// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.

// implement the math using the bls library

import { ProjPointType } from '@noble/curves/abstract/weierstrass';
import { bls12_381 as bls } from '@noble/curves/bls12-381';

// unexported types from bls
type Fp = bigint;
type Fp2 = { c0: bigint; c1: bigint };

// abstract point class
class Point<T> {
    point: ProjPointType<T>;
    constructor(point: ProjPointType<T>) {
        this.point = point;
    }
    toBytes(): Uint8Array {
        return this.point.toRawBytes(true /* compressed */);
    }
    mul(scalar: bigint): Point<T> {
        return new Point<T>(this.point.multiply(scalar));
    }
    add(p: Point<T>): Point<T> {
        return new Point<T>(this.point.add(p.point));
    }
    neg(): Point<T> {
        return new Point<T>(this.point.negate());
    }
    equals(p: Point<T>): boolean {
        return this.point.equals(p.point);
    }
}

// G1 point
export class PointG1 extends Point<Fp> {
    constructor(point: ProjPointType<Fp>) {
        super(point);
    }
    static Identity = new PointG1(bls.G1.ProjectivePoint.ZERO);
    static fromBytes(bytes: Uint8Array): PointG1 {
        return new PointG1(bls.G1.ProjectivePoint.fromHex(bytes)); // fromHex takes bytes...
    }
    static async hashToCurve(msg: Uint8Array, dst: string): Promise<PointG1> {
        const candidate = await bls.G1.hashToCurve(msg, { DST: dst });
        return new PointG1(candidate as ProjPointType<bigint>); // FIXME: cast works?
    }
}

// G2 point
export class PointG2 extends Point<Fp2> {
    constructor(point: ProjPointType<Fp2>) {
        super(point);
    }
    static Identity = new PointG2(bls.G2.ProjectivePoint.ZERO);
    static Base = new PointG2(bls.G2.ProjectivePoint.BASE);
    static fromBytes(bytes: Uint8Array, doSubgroupCheck = false): PointG2 {
        return new PointG2(bls.G2.ProjectivePoint.fromHex(bytes)); // fromHex takes bytes...
    }
    static subgroup_check(a: PointG2): boolean {
        try {
            a.point.assertValidity();
            return true; // valid point
        } catch (e) {
            return false; // invalid point
        }
    }
}

// checks that e(pointG1_1, pointG2_1) * e(pointG1_2, pointG2_2) = GT_Identity
export function checkPairingIsIdentity(pointG1_1: PointG1, pointG2_1: PointG2, pointG1_2: PointG1, pointG2_2: PointG2): boolean {
    // (using the pairing optimization to skip final exponentiation in the pairing
    // and do it after the multiplication)
    const lh = bls.pairing(pointG1_1.point, pointG2_1.point /* TODO, false */);
    const rh = bls.pairing(pointG1_2.point, pointG2_2.point/* TODO, false */);
    let result = bls.fields.Fp12.mul(lh, rh);
    //        result = bls.fields.Fp12.finalExponentiate(result);// TODO: why is finalExponentiate not available???
    return bls.fields.Fp12.eql(result, bls.fields.Fp12.ONE);
}

// scalar field of order r
export class Fr {
    static blsFr = bls.fields.Fr;

    static fromBigint(i: bigint): bigint {
        return Fr.blsFr.create(i);
    }
    static mul(a: bigint, b: bigint): bigint {
        return Fr.blsFr.mul(a, b);
    }
    static inv(a: bigint): bigint {
        return Fr.blsFr.inv(a);
    }
    static add(a: bigint, b: bigint): bigint {
        return Fr.blsFr.add(a, b);
    }
    static neg(a: bigint): bigint {
        return Fr.blsFr.neg(a);
    }
    static checkNonZero(a: bigint, error: string) {
        if (a === 0n || a >= Fr.blsFr.ORDER) throw error;
    }
}